async function load() {
  try {
    let res = await fetch("/api/latest");
    if (!res.ok) throw 0;

    let d = await res.json();

    document.getElementById("uptime").innerText = d.uptime;
    document.getElementById("cpu").innerText = d.cpu;
    document.getElementById("mem").innerText = d.mem;
    document.getElementById("wan").innerText = d.wan ? `${d.wan.rx} / ${d.wan.tx}` : "—";

    let tb = document.querySelector("#clients tbody");
    tb.innerHTML = "";

    (d.clients || []).forEach(c => {
      tb.innerHTML += `<tr>
        <td>${c.ip}</td>
        <td>${c.mac}</td>
        <td>${c.hostname || "-"}</td>
      </tr>`;
    });

    document.getElementById("status").innerText = "Live ✔";
  }
  catch(e) {
    document.getElementById("status").innerText = "Offline / No router data";
  }
}

setInterval(load, 3000);
load();