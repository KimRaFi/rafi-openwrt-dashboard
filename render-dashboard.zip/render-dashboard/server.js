const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const app = express();

app.use(bodyParser.json({ limit: "200kb" }));
app.use(express.static(path.join(__dirname, "public")));

const SECRET = process.env.RAFI_SECRET || "changeme";
let latest = null;

// Receive router telemetry
app.post("/api/telemetry", (req, res) => {
  const token = req.header("x-raf-token");
  if (!token || token !== SECRET) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  latest = req.body;
  latest._ts = Date.now();

  res.json({ ok: true });
});

// Send telemetry to dashboard
app.get("/api/latest", (req, res) => {
  if (!latest) return res.status(404).json({ error: "No Data Yet" });
  res.json(latest);
});

app.listen(process.env.PORT || 3000, () => {
  console.log("Server running...");
});